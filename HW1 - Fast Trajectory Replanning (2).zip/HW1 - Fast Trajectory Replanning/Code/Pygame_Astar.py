import pygame
import math
import random
import time
from queue import PriorityQueue

WIDTH = 800
WIN = pygame.display.set_mode((WIDTH, WIDTH))
pygame.display.set_caption("A* Path Finding Algorithm")

RED = (255, 0, 0)
GREEN = (0, 255, 0)
BLUE = (0, 255, 0)
YELLOW = (255, 255, 0)
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
PURPLE = (128, 0, 128)
ORANGE = (255, 165 ,0)
GREY = (128, 128, 128)
TURQUOISE = (64, 224, 208)

class Spot:
    def __init__(self, row, col, width, total_rows):
        self.row = row
        self.col = col
        self.x = row * width
        self.y = col * width
        self.color = WHITE
        self.neighbors = []
        self.width = width
        self.total_rows = total_rows
        self.g_value = float("inf")  # Initialize g-value as infinity
        self.f_value = float("inf") #Initialize f-value as infinity
        
    def get_g_value(self):
        return self.g_value
    def get_f_value(self):
        return self.f_value
    
    def set_g_value(self,value):
        self.g_value = value
        
    def set_f_value(self, value):
        self.f_value = value
    def get_pos(self):
        return self.row, self.col

    def is_closed(self):
        return self.color == RED

    def is_open(self):
        return self.color == GREEN

    def is_barrier(self):
        return self.color == BLACK

    def is_start(self):
        return self.color == ORANGE

    def is_end(self):
        return self.color == TURQUOISE

    def reset(self):
        self.color = WHITE

    def make_start(self):
        self.color = ORANGE

    def make_closed(self):
        self.color = RED

    def make_open(self):
        self.color = GREEN

    def make_barrier(self):
        self.color = BLACK

    def make_end(self):
        self.color = TURQUOISE

    def make_path(self):
        self.color = PURPLE

    def draw(self, win):
        pygame.draw.rect(win, self.color, (self.x, self.y, self.width, self.width))
    
    def set_h_value(self, value):
        self.h_value = value

    def update_neighbors(self, grid):
        self.neighbors = []
        if self.row < self.total_rows - 1 and not grid[self.row + 1][self.col].is_barrier():  # DOWN
            self.neighbors.append(grid[self.row + 1][self.col])

        if self.row > 0 and not grid[self.row - 1][self.col].is_barrier():  # UP
            self.neighbors.append(grid[self.row - 1][self.col])

        if self.col < self.total_rows - 1 and not grid[self.row][self.col + 1].is_barrier():  # RIGHT
            self.neighbors.append(grid[self.row][self.col + 1])

        if self.col > 0 and not grid[self.row][self.col - 1].is_barrier():  # LEFT
            self.neighbors.append(grid[self.row][self.col - 1])



    def __lt__(self, other):
        return False


def update_heuristic_values(grid, end):
    for row in grid:
        for spot in row:
            if spot != end and not spot.is_barrier():
                spot.set_h_value(h(spot.get_pos(), end.get_pos()))


def h(p1, p2):
    x1, y1 = p1
    x2, y2 = p2
    return abs(x1 - x2) + abs(y1 - y2)



def reconstruct_path(came_from, current, draw):
    while current in came_from:
        current = came_from[current]
        current.make_path()
        draw()


prev_g_values = {}

class Cell:
    def __init__(self, row, col, g=0, h=0, f=0, parent=None):
        self.row = row
        self.col = col
        self.g_value = g
        self.h_value = h
        self.f_value = f
        self.parent = parent

    def update_values(self, g, h, f, parent):
        self.g_value = g
        self.h_value = h
        self.f_value = f
        self.parent = parent

def aStar(draw, grid, start, end, cells, search_direction='forward', tie_breaking='larger_g'):
    global H  # Declare H as global
    
    # Initialize H with Manhattan distances
    H = [[h((i, j), end.get_pos()) for j in range(len(grid[0]))] for i in range(len(grid))]
    
    count = 0
    open_set = PriorityQueue()
    c = 10000  # A constant larger than the largest possible g-value

    expanded_nodes_count = 0  # Initialize expanded nodes counter

    open_set.put((0, count, start))
    target = end

    came_from = {}
    g_score = {spot: spot.get_g_value() for row in grid for spot in row}
    g_score[start] = 0
    f_score = {spot: spot.get_f_value() for row in grid for spot in row}
    f_score[start] = h(start.get_pos(), end.get_pos())

    previous_g_values = {}
    open_set_hash = {start}

    while not open_set.empty():
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()

        current = open_set.get()[2]
        expanded_nodes_count += 1  # Increment the counter when a node is expanded
        open_set_hash.remove(current)

        if current == target:
            reconstruct_path(came_from, target, draw)
            target.make_end()
            # You can choose to print the counts here or return them
            print(f"Expanded Nodes: {expanded_nodes_count}")
            return True, previous_g_values, expanded_nodes_count

        for neighbor in current.neighbors:
            temp_g_score = g_score[current] + 1

            if temp_g_score < g_score[neighbor]:
                came_from[neighbor] = current
                g_score[neighbor] = temp_g_score
                if search_direction == 'forward':
                    f = temp_g_score + H[neighbor.row][neighbor.col]  # Use H for f-value computation
                else:
                    f = temp_g_score + H[neighbor.row][neighbor.col]  # Use H for f-value computation

                f_score[neighbor] = f

                if tie_breaking == 'larger_g':
                    priority = c * f - g_score[neighbor]
                else:  # 'smaller_g'
                    priority = c * f + g_score[neighbor]

                if neighbor not in open_set_hash:
                    count += 1
                    open_set.put((priority, count, neighbor))
                    open_set_hash.add(neighbor)
                    neighbor.make_open()

        draw()

        if current != start:
            current.make_closed()

        previous_g_values[current] = g_score[current]

    return False, previous_g_values

def adaptive_a_star(draw, grid, start, end):
    count = 0
    expanded_nodes_count = 0  # Initialize expanded nodes count
    open_set = PriorityQueue()
    open_set.put((0, count, start))
    came_from = {}
    g_score = {spot: float("inf") for row in grid for spot in row}
    g_score[start] = 0

    # Initialize heuristic values based on Manhattan distance
    f_score = {spot: h(spot.get_pos(), end.get_pos()) for row in grid for spot in row}
    f_score[start] = h(start.get_pos(), end.get_pos())

    open_set_hash = {start}

    while not open_set.empty():
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()

        current = open_set.get()[2]
        open_set_hash.remove(current)
        expanded_nodes_count += 1  # Increment expanded nodes count

        if current == end:
            reconstruct_path(came_from, end, draw)
            end.make_end()
            # Update heuristic values based on the found path
            update_heuristic_values(grid, end)
            return True, expanded_nodes_count  # Return path found and expanded nodes count

        for neighbor in current.neighbors:
            temp_g_score = g_score[current] + 1

            if temp_g_score < g_score[neighbor]:
                came_from[neighbor] = current
                g_score[neighbor] = temp_g_score
                f_score[neighbor] = temp_g_score + h(neighbor.get_pos(), end.get_pos())

                if neighbor not in open_set_hash:
                    count += 1
                    open_set.put((f_score[neighbor], count, neighbor))
                    open_set_hash.add(neighbor)
                    neighbor.make_open()

        draw()

        if current != start:
            current.make_closed()

    return False, expanded_nodes_count  # Return path not found and expanded nodes count




def repeated_forward_AStar(draw, grid, start, end):
    count = 0
    expanded_nodes = 0  # Initialize expanded nodes count
    open_set = PriorityQueue()
    open_set.put((0, count, start))
    came_from = {}
    g_score = {spot: float("inf") for row in grid for spot in row}
    g_score[start] = 0
    f_score = {spot: float("inf") for row in grid for spot in row}
    f_score[start] = h(start.get_pos(), end.get_pos())

    open_set_hash = {start}

    while not open_set.empty():
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()

        current = open_set.get()[2]
        open_set_hash.remove(current)
        expanded_nodes += 1  # Increment expanded nodes count

        if current == end:
            reconstruct_path(came_from, end, draw)
            end.make_end()
            return True, expanded_nodes  # Return path found and expanded nodes count

        for neighbor in current.neighbors:
            temp_g_score = g_score[current] + 1

            if temp_g_score < g_score[neighbor]:
                came_from[neighbor] = current
                g_score[neighbor] = temp_g_score
                f_score[neighbor] = temp_g_score + h(neighbor.get_pos(), end.get_pos())
                if neighbor not in open_set_hash:
                    count += 1
                    open_set.put((f_score[neighbor], count, neighbor))
                    open_set_hash.add(neighbor)
                    neighbor.make_open()

        draw()

        if current != start:
            current.make_closed()

    return False, expanded_nodes  # Return path not found and expanded nodes count


def repeated_backward_AStar(draw, grid, start, end):
    count = 0
    expanded_nodes_count = 0  # Initialize expanded nodes count
    open_set = PriorityQueue()
    open_set.put((0, count, start))  # Start from the bottom right corner
    came_from = {}
    g_score = {spot: float("inf") for row in grid for spot in row}
    g_score[start] = 0
    f_score = {spot: float("inf") for row in grid for spot in row}
    f_score[start] = h(start.get_pos(), end.get_pos())  # Heuristic from bottom right to top left

    open_set_hash = {start}

    while not open_set.empty():
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()

        current = open_set.get()[2]
        open_set_hash.remove(current)
        expanded_nodes_count += 1  # Increment expanded nodes count

        if current == end:  # Goal is the top left corner
            reconstruct_path(came_from, end, draw)
            end.make_start()  # Mark the original end (top left) as start
            return True, expanded_nodes_count  # Return path found and expanded nodes count

        for neighbor in current.neighbors:
            temp_g_score = g_score[current] + 1

            if temp_g_score < g_score[neighbor]:
                came_from[neighbor] = current
                g_score[neighbor] = temp_g_score
                f_score[neighbor] = temp_g_score + h(neighbor.get_pos(), end.get_pos())

                if neighbor not in open_set_hash:
                    count += 1
                    open_set.put((f_score[neighbor], count, neighbor))
                    open_set_hash.add(neighbor)
                    neighbor.make_open()

        draw()

        if current != start:
            current.make_closed()

    return False, expanded_nodes_count  # Return path not found and expanded nodes count


def make_grid(rows, width):
    # grid = []
    # gap = width // rows
    # for i in range(rows):
    # 	grid.append([])
    # 	for j in range(rows):
    # 		spot = Spot(i, j, gap, rows)
    # 		grid[i].append(spot)

    # return grid
    grid = []
    gap = width // rows
    for i in range(rows):
        grid.append([])
        for j in range(rows):
            spot = Spot(i, j, gap, rows)
            if (i, j) == (0, 0):
                spot.make_start()
            elif (i, j) == (rows - 1, rows - 1):
                spot.make_end()
            elif random.random() < 0.3:  # Adjust the probability here
                spot.make_barrier()
            grid[i].append(spot)
    return grid


def draw_grid(win, rows, width):
    gap = width // rows
    for i in range(rows):
        pygame.draw.line(win, GREY, (0, i * gap), (width, i * gap))
        for j in range(rows):
            pygame.draw.line(win, GREY, (j * gap, 0), (j * gap, width))


# 1
# def draw(win, grid, rows, width):
# 	win.fill(WHITE)

# 	for row in grid:
# 		for spot in row:
# 			spot.draw(win)

# 	draw_grid(win, rows, width)
# 	pygame.display.update()
# 2
def draw(win, grid, rows, width):
    win.fill(WHITE)

    # Calculate the size of each cell
    cell_size = width // rows

    for row in grid:
        for spot in row:
            # Calculate the position and size of the spot rectangle
            x = spot.col * cell_size
            y = spot.row * cell_size
            rect = pygame.Rect(x, y, cell_size, cell_size)

            # Draw the spot rectangle with its color
            pygame.draw.rect(win, spot.color, rect)

    pygame.display.update()

#3
# def draw(win, grid, rows, width):
#     win.fill(WHITE)

#     # Calculate the size of each cell
#     cell_size = width // rows

#     for row in grid:
#         for spot in row:
#             # Calculate the position and size of the spot rectangle
#             x = spot.col * cell_size
#             y = spot.row * cell_size
#             rect = pygame.Rect(x, y, cell_size, cell_size)

#             # Add a gradient effect to the spot color
#             color_top = spot.color
#             color_bottom = tuple(min(255, c + 50) for c in spot.color)  # Lighten the color for bottom gradient
#             pygame.draw.rect(win, color_top, rect)
#             pygame.draw.rect(win, color_bottom, rect, border_radius=10)  # Add rounded corners

#             # Draw a border around the spot rectangle
#             pygame.draw.rect(win, BLACK, rect, 2)

#     pygame.display.update()

#one has line in the grid and the other 
def get_clicked_pos(pos, rows, width):
    gap = width // rows
    y, x = pos

    row = y // gap
    col = x // gap

    return row, col

def execute_astar(draw, win, grid, start, end, cells, direction, tie_breaking, rows, width):
    start_time = time.time()

    if direction == 'forward':
        aStar(lambda: draw(win, grid, rows, width), grid, start, end, cells, search_direction='forward', tie_breaking=tie_breaking)
    elif direction == 'backward':
        aStar(lambda: draw(win, grid, rows, width), grid, end, start, cells, search_direction='backward', tie_breaking=tie_breaking)

    end_time = time.time()
    runtime = end_time - start_time
    print(f'Total Time: {runtime:.4f} s')





def main(win, width):
    ROWS = 100
    grid = make_grid(ROWS, width)
    original_grid = [row[:] for row in grid]  # Create a copy of the original grid
    start = None
    end = None
    run = True
    mode = None
    tie_breaking = None  # Added for tie-breaking strategy
    search_direction = 'forward'  # Default search direction
    repeated_forward = False
    repeated_backward = False
    adaptive_a_star_mode = False

    while run:
        draw(win, grid, ROWS, width)
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                run = False
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_c:
                    grid = make_grid(ROWS, width)
                    original_grid = [row[:] for row in grid]  # Reset the original grid
                if event.key == pygame.K_f:
                    mode = 'forward'
                    search_direction = 'forward'  # Set search direction to forward
                    grid = [row[:] for row in original_grid]
                if event.key == pygame.K_b:
                    mode = 'backward'
                    search_direction = 'backward'  # Set search direction to backward
                    grid = [row[:] for row in original_grid]
                if event.key == pygame.K_s:  # Small-g tie-breaking
                    tie_breaking = 'smaller_g'
                if event.key == pygame.K_l:  # Large-g tie-breaking
                    tie_breaking = 'larger_g'
                if event.key == pygame.K_r:  # Press 'r' to run repeated forward A*
                    repeated_forward = True
                    repeated_backward = False  # Ensure repeated_backward is False
                    mode = 'repeated_forward'
                if event.key == pygame.K_q:  # Press 'q' to run repeated backward A*
                    repeated_backward = True
                    repeated_forward = False  # Ensure repeated_forward is False
                    mode = 'repeated_backward'
                if event.key == pygame.K_a:  # Press 'a' to run Adaptive A*
                    adaptive_a_star_mode = True
                    repeated_forward = False
                    repeated_backward = False
                    mode = 'adaptive_a_star'

                if event.key == pygame.K_RETURN:  # Press enter to start the algorithm
                    for row in grid:
                        for spot in row:
                            spot.update_neighbors(grid)

                    if mode == 'forward' or repeated_forward:
                        print("Running Forward A*")
                        start, end = grid[0][0], grid[ROWS - 1][ROWS - 1]
                        start.make_start()
                        end.make_end()
                    elif mode == 'backward' or repeated_backward:
                        print("Running Backward A*")
                        start, end = grid[ROWS - 1][ROWS - 1], grid[0][0]
                        start.make_start()
                        end.make_end()

                    cells = {spot: Cell(spot.row, spot.col) for row in grid for spot in row}

                    if mode == 'repeated_forward':
                        for row in grid:
                                    for spot in row:
                                        if spot.color in (RED, GREEN, PURPLE):
                                            spot.reset()
                        print("Running Repeated Forward A*")
                        start_time = time.time()
                        _, expanded_nodes = repeated_forward_AStar(lambda: draw(win, grid, ROWS, width), grid, start, end)  # Capture expanded nodes count
                        end_time = time.time()
                        runtime = end_time - start_time
                        print(f'Total Time: {runtime:.4f} s, Expanded Nodes: {expanded_nodes}')

                    elif mode == 'repeated_backward':
                        for row in grid:
                                    for spot in row:
                                        if spot.color in (RED, GREEN, PURPLE):
                                            spot.reset()
                        print("Running Repeated Backward A*")
                        start, end = grid[ROWS - 1][ROWS - 1], grid[0][0]  # Set start to bottom right and end to top left
                        start.make_start()
                        end.make_end()
                        start_time = time.time()
                        _, expanded_nodes = repeated_backward_AStar(lambda: draw(win, grid, ROWS, width), grid, start, end)  # Capture expanded nodes count
                        end_time = time.time()
                        runtime = end_time - start_time
                        print(f'Total Time: {runtime:.4f} s, Expanded Nodes: {expanded_nodes}')

                    elif mode == 'adaptive_a_star':
                        for row in grid:
                                    for spot in row:
                                        if spot.color in (RED, GREEN, PURPLE):
                                            spot.reset()
                        print("Running Adaptive A*")
                        start, end = grid[0][0], grid[ROWS - 1][ROWS - 1]  # Set start and end
                        start.make_start()
                        end.make_end()
                        start_time = time.time()
                        _, expanded_nodes = adaptive_a_star(lambda: draw(win, grid, ROWS, width), grid, start, end)  # Capture expanded nodes count
                        end_time = time.time()
                        runtime = end_time - start_time
                        print(f'Total Time: {runtime:.4f} s, Expanded Nodes: {expanded_nodes}')


                    else:
                        for row in grid:
                                    for spot in row:
                                        if spot.color in (RED, GREEN, PURPLE):
                                            spot.reset()
                        mode_str = mode.capitalize() if mode else "None"  # Check if mode is not None
                        tie_breaking_str = tie_breaking.capitalize() if tie_breaking else "None"  # Check if tie_breaking is not None
                        print(f"Running {mode_str} A* with {tie_breaking_str} tie-breaking")  # Use mode_str and tie_breaking_str instead
                        start.make_start()
                        end.make_end()
                        start_time = time.time()
                        aStar(lambda: draw(win, grid, ROWS, width), grid, start, end, cells, search_direction=search_direction, tie_breaking=tie_breaking)
                        end_time = time.time()
                        runtime = end_time - start_time
                        
                        print(f'Total Time: {runtime:.4f} s')
                        

    pygame.quit()




main(WIN, WIDTH)