#Author: Shivam Patel, Harsh Patel 

import heapq
import random
import time
import numpy as np

class colors:
    PURPLE = '\033[95m'
    BLUE = '\033[94m'
    GREEN = '\033[92m'
    YELLOW = '\033[93m'
    RED = '\033[91m'
    ORANGE = '\033[38;5;202m'  # ANSI escape code for orange color
    GOLDEN = '\033[38;5;214m'  # ANSI escape code for golden color
    ENDC = '\033[0m'

def heuristic(a, b):
    return abs(a[0] - b[0]) + abs(a[1] - b[1])

g_values = {}

import heapq
import random

def a_star(start, goal, grid, forward=True, break_ties_smaller_g=True):
    open_set = []
    heapq.heappush(open_set, (0, start, random.random()))  # Include random value for tie-breaking
    
    came_from = {}
    g_score = {start: 0}
    f_score = {start: heuristic(start, goal)}
    expanded_cells = 0

    while open_set:
        current = heapq.heappop(open_set)[1]
        expanded_cells += 1

        if current == goal:
            path = []
            while current in came_from:
                path.append(current)
                current = came_from[current]
            path.append(start)  # Include start in the path
            return path[::-1] if forward else path, expanded_cells

        for neighbor in [(0,1),(0,-1),(1,0),(-1,0)]:
            next_node = (current[0] + neighbor[0], current[1] + neighbor[1])
            
            if 0 <= next_node[0] < len(grid) and 0 <= next_node[1] < len(grid[0]) and grid[next_node[0]][next_node[1]] == 0:
                tentative_g_score = g_score[current] + 1
                if tentative_g_score < g_score.get(next_node, float('inf')):
                    came_from[next_node] = current
                    g_score[next_node] = tentative_g_score
                    f_score[next_node] = tentative_g_score + heuristic(next_node, goal)
                    c = max(g_score.values()) + 1  # Constant larger than the largest g-value
                    
                    if break_ties_smaller_g:
                        heapq.heappush(open_set, (c * f_score[next_node] + g_score[next_node], next_node, random.random()))
                    else:
                        heapq.heappush(open_set, (c * f_score[next_node] - g_score[next_node], next_node, random.random()))
    
    return None, expanded_cells

# # We used 2d array but also tried with DFS. 
# def dfs_generate_maze(rows, cols):
#     maze = np.ones((rows, cols), dtype=int)  # Initialize maze with all cells as blocked
#     stack = [(0, 0)]  # Start DFS from top-left corner
#     visited = set([(0, 0)])  # Keep track of visited cells

#     while stack:
#         current_cell = stack[-1]  # Get the current cell
#         neighbors = [(current_cell[0] + dx, current_cell[1] + dy) for dx, dy in [(0, 1), (0, -1), (1, 0), (-1, 0)]]

#         unvisited_neighbors = [neighbor for neighbor in neighbors if 0 <= neighbor[0] < rows and 0 <= neighbor[1] < cols and neighbor not in visited]
        
#         if unvisited_neighbors:
#             next_cell = random.choice(unvisited_neighbors)
#             stack.append(next_cell)
#             visited.add(next_cell)

#             # Mark the path between current cell and next cell as unblocked
#             row, col = current_cell
#             next_row, next_col = next_cell
#             maze[(row + next_row) // 2][(col + next_col) // 2] = 0

#             # Mark the next cell as unblocked
#             maze[next_row][next_col] = 0

#         else:
#             stack.pop()  # Backtrack

#     return maze

def draw_maze(maze):
    for row in maze:
        for cell in row:
            if cell == 1:
                print(colors.GOLDEN + "X" + colors.ENDC, end=" ")
            else:
                print(".", end=" ")
        print()

g_values = {}



def adaptive_astar(start, goal, grid, h_values):
    open_set = []
    heapq.heappush(open_set, (0, start))

    came_from = {}
    g_score = {start: 0}
    f_score = {start: heuristic(start, goal)}
    
    expanded_cells = 0
    expanded_nodes = []  # Keep track of expanded nodes for heuristic updates

    while open_set:
        current = heapq.heappop(open_set)[1]
        expanded_cells += 1
        expanded_nodes.append(current)  # Add current node to expanded nodes

        if current == goal:
            # Update heuristics for all expanded nodes
            for node in expanded_nodes:
                h_values[node] = g_score[goal] - g_score[node]
        
            # Update f_scores for the open set with new heuristic values
            for i, (f, node) in enumerate(open_set):
                new_f = g_score[node] + h_values.get(node, heuristic(node, goal))
                open_set[i] = (new_f, node)
            heapq.heapify(open_set)  # Rebuild the heap based on the new f_scores

            # Construct and return the path
            path = []
            while current in came_from:
                path.append(current)
                current = came_from[current]
            path.append(start)
            return path[::-1], expanded_cells

        for neighbor in [(0, 1), (0, -1), (1, 0), (-1, 0)]:
            next_node = (current[0] + neighbor[0], current[1] + neighbor[1])

            if 0 <= next_node[0] < len(grid) and 0 <= next_node[1] < len(grid[0]) and grid[next_node[0]][next_node[1]] == 0:
                tentative_g_score = g_score[current] + 1

                if tentative_g_score < g_score.get(next_node, float('inf')):
                    came_from[next_node] = current
                    g_score[next_node] = tentative_g_score
                    f_score[next_node] = tentative_g_score + heuristic(next_node, goal)
                    heapq.heappush(open_set, (f_score[next_node], next_node))

    return None, expanded_cells

def a_star_breakTies(start, goal, grid, break_ties_smaller_g=True):
    open_set = []
    heapq.heappush(open_set, (0, start))

    
    came_from = {}
    g_score = {start: 0}
    f_score = {start: heuristic(start, goal)}
    expanded_cells = 0
    while open_set:
        current = heapq.heappop(open_set)[1]
        expanded_cells += 1
        if current == goal:
            path = []
            while current in came_from:
                path.append(current)
                current = came_from[current]
            path.append(current)
            return path[::-1], expanded_cells
        
        for neighbor in [(0,1),(0,-1),(1,0),(-1,0)]:
            next_node = (current[0] + neighbor[0], current[1] + neighbor[1])
            
            if next_node[0] < 0 or next_node[0] >= len(grid) or next_node[1] < 0 or next_node[1] >= len(grid[0]):
                continue
            
            if grid[next_node[0]][next_node[1]] == 1:
                continue
            
            tentative_g_score = g_score[current] + 1
            
            if next_node not in g_score or tentative_g_score < g_score[next_node]:
                came_from[next_node] = current
                g_score[next_node] = tentative_g_score
                f_score[next_node] = g_score[next_node] + heuristic(next_node, goal)
                
                if break_ties_smaller_g:
                    c = max(g_score.values()) + 1
                    heapq.heappush(open_set, (c * f_score[next_node] + g_score[next_node], next_node))
                else:
                    c = max(g_score.values()) + 1
                    heapq.heappush(open_set, (c * f_score[next_node] - g_score[next_node], next_node))
    
    return None, expanded_cells

def robot_path(start, goal, grid):
    path = a_star(start, goal, grid)
    if path is None:
        return None
    else:
        return path

def make_grid(rows, cols):
    # Initialize the maze with unblocked cells
    maze = np.zeros((rows, cols), dtype=int)
    # Place obstacles randomly except for the start and goal positions
    for i in range(rows):
        for j in range(cols):
            if (i, j) != (0, 0) and (i, j) != (rows - 1, cols - 1):
                if random.random() < 0.3:  # 30% chance of obstacle
                    maze[i][j] = 1
    return maze

def draw_grid(grid, path=None, backward=False):
    for i in range(len(grid)):
        for j in range(len(grid[0])):
            # Check if the current cell is part of the path
            is_path = path is not None and (i, j) in path

            # Determine the start and end points based on the search direction
            start_point = (0, 0) if not backward else (len(grid) - 1, len(grid[0]) - 1)
            end_point = (len(grid) - 1, len(grid[0]) - 1) if not backward else (0, 0)

            # Print the start point
            if is_path and (i, j) == start_point:
                print(colors.GREEN + "A" + colors.ENDC, end=" ")
            # Print the end point
            elif is_path and (i, j) == end_point:
                print(colors.RED + "G" + colors.ENDC, end=" ")
            # Print the path
            elif is_path:
                print(colors.BLUE + "_" + colors.ENDC, end=" ")
            # Print obstacles
            elif grid[i][j] == 1:
                print(colors.GOLDEN + "X" + colors.ENDC, end=" ")
            # Print empty cells
            else:
                print(".", end=" ")
        print()

ROWS = 60
COLS = 60

def print_mean_results(num_valid_mazes, total_time_forward, total_time_backward, total_time_adaptive, 
                       total_time_smallG, total_time_largeG, total_nodes_forward, total_nodes_backward, 
                       total_nodes_adaptive, total_nodes_smallG, total_nodes_largeG):
    print("\nMean Time and Nodes for Repeated Forward A*:")
    print(f"Time taken: {total_time_forward / num_valid_mazes} seconds")
    print(f"Expanded nodes: {total_nodes_forward / num_valid_mazes}")
    print()
    print("Mean Time and Nodes for Repeated Backward A*:")
    print(f"Time taken: {total_time_backward / num_valid_mazes} seconds")
    print(f"Expanded nodes: {total_nodes_backward / num_valid_mazes}")
    print()
    print("Mean Time and Nodes for Adaptive A*:")
    print(f"Time taken: {total_time_adaptive / num_valid_mazes} seconds")
    print(f"Expanded nodes: {total_nodes_adaptive / num_valid_mazes}")
    print()
    print("Mean Time and Nodes for Repeated Forward A* with Smaller G:")
    print(f"Time taken: {total_time_smallG / num_valid_mazes} seconds")
    print(f"Expanded nodes: {total_nodes_smallG / num_valid_mazes}")
    print()
    print("Mean Time and Nodes for Repeated Forward A* with Larger G:")
    print(f"Time taken: {total_time_largeG / num_valid_mazes} seconds")
    print(f"Expanded nodes: {total_nodes_largeG / num_valid_mazes}")

# # Generate and run algorithms on 50 mazes
num_mazes = 50
num_valid_mazes = 0
total_time_forward = 0
total_time_backward = 0
total_time_adaptive = 0
total_time_smallG = 0
total_time_largeG = 0
total_nodes_forward = 0
total_nodes_backward = 0
total_nodes_adaptive = 0
total_nodes_smallG = 0
total_nodes_largeG = 0

    #while successful_runs < num_mazes:
#for _ in range(50):
while num_valid_mazes < num_mazes:
    print(f"Running maze {num_valid_mazes + 1}/{num_mazes}")
    maze = make_grid(ROWS, COLS)
    start = (0, 0)
    goal = (ROWS - 1, COLS - 1)
    
    # Repeated Forward A*
    start_time = time.time()
    path_forward, numNodes_forward = a_star(start, goal, maze, forward=True)
    end_time = time.time()
    if path_forward is not None:
        total_time_forward += end_time - start_time
        total_nodes_forward += numNodes_forward
        num_valid_mazes += 1

        # Repeated Backward A*
        start_time = time.time()
        path_backward, numNodes_backward = a_star(goal, start, maze, forward=False)
        end_time = time.time()
        if path_backward is not None:
            total_time_backward += end_time - start_time
            total_nodes_backward += numNodes_backward

        # Adaptive A*
        start_time = time.time()
        h_values = {}
        path_adaptive, numNodes_adaptive = adaptive_astar(start, goal, maze, h_values)
        end_time = time.time()
        if path_adaptive:
            total_time_adaptive += end_time - start_time
            total_nodes_adaptive += numNodes_adaptive

        # Repeated Forward A* with Smaller G
        start_time = time.time()
        path_smallG, numNodes_smallG = a_star_breakTies(start, goal, maze, break_ties_smaller_g=True)
        end_time = time.time()
        if path_smallG:
            total_time_smallG += end_time - start_time
            total_nodes_smallG += numNodes_smallG

        # Repeated Forward A* with Larger G
        start_time = time.time()
        path_largeG, numNodes_largeG = a_star_breakTies(start, goal, maze, break_ties_smaller_g=False)
        end_time = time.time()
        if path_largeG:
            total_time_largeG += end_time - start_time
            total_nodes_largeG += numNodes_largeG

print_mean_results(num_valid_mazes, total_time_forward, total_time_backward, total_time_adaptive, 
                total_time_smallG, total_time_largeG, total_nodes_forward, total_nodes_backward, 
                total_nodes_adaptive, total_nodes_smallG, total_nodes_largeG)

#Print the last maze with paths and run all algorithms
print("\nLast Maze with Paths and Visualizations for Each Algorithm:")
print("------------------------------------------------------------")

maze = make_grid(ROWS, COLS)
start = (0, 0)
goal = (ROWS - 1, COLS - 1)
print("Intial Maze")
draw_grid(maze)

print("\nRepeated Forward A*")
start_time = time.time()
path_forward, numNodes_forward = a_star(start, goal, maze, forward=True)
end_time = time.time()
print(f"Time taken: {end_time - start_time} seconds")
print(f"Expanded nodes: {numNodes_forward}")
if path_forward:
    draw_grid(maze, path_forward)
else:
    print("Goal is unreachable.")

print("\nRepeated Backward A*")
start_time = time.time()
path_backward, numNodes_backward = a_star(start, goal, maze, forward=False)
end_time = time.time()
print(f"Time taken: {end_time - start_time} seconds")
print(f"Expanded nodes: {numNodes_backward}")
if path_backward:
    draw_grid(maze, path_backward)
else:
    print("Start is unreachable.")

h_values = {}
print("\nAdaptive A*")
start_time = time.time()
path_adaptive, numNodes_adaptive = adaptive_astar(start, goal, maze, h_values)
end_time = time.time()
print(f"Time taken: {end_time - start_time} seconds")
print(f"Expanded nodes: {numNodes_adaptive}")
if path_adaptive:
    draw_grid(maze, path_adaptive)
else:
    print("No path found.")

print("\nRepeated Forward A* with Smaller G")
start_time = time.time()
path_smallG, numNodes_smallG = a_star_breakTies(start, goal, maze, break_ties_smaller_g=True)
end_time = time.time()
print(f"Time taken: {end_time - start_time} seconds")
print(f"Expanded nodes: {numNodes_smallG}")
if path_smallG:
    draw_grid(maze, path_smallG)
else:
    print("Goal is unreachable.")

print("\nRepeated Forward A* with Larger G")
start_time = time.time()
path_largeG, numNodes_largeG = a_star_breakTies(start, goal, maze, break_ties_smaller_g=False)
end_time = time.time()
print(f"Time taken: {end_time - start_time} seconds")
print(f"Expanded nodes: {numNodes_largeG}")
if path_largeG:
    draw_grid(maze, path_largeG)
else:
    print("Goal is unreachable.")